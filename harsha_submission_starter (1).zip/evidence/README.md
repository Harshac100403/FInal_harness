# Evidence checklist — complete with your own runs

**Learner:** Harsha  
**Email:** harshah38438@gmail.com

This is a clean starter package, not a completed submission. Existing learner-specific logs, run outputs, and reflection text were intentionally excluded so they are not accidentally submitted as your own.

Create the following folders and save fresh evidence from your own Vocareum workspace:

- `system1_agentic_loop/`: `pytest -v` log, run log, generated run ID/output folder, trace JSONL files, and summary.
- `system2_context_strategy/`: test log, run log, generated `budget.json`, `eval.jsonl`, and `eval_control.jsonl`.
- `system3_claude_config/`: validator output and exit status, `pytest -v` log, and the relevant configuration/rule files required by the assignment.
- `system4_orchestration/`: test log, actual shift-run output, filtered-slice evidence, measured hot-state size, and scratchpad record.

Do not edit output counts or fabricate missing artifacts. If a command fails, preserve the failure log and document the fix and the successful rerun. Never include API keys in evidence.
